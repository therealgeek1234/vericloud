let currentBase64Image = null; 

function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const target = document.getElementById(`screen-${screenId}`);
    if (target) target.classList.add('active');
    
    // Load history from LocalStorage when navigating to history screen
    if (screenId === 'history') loadHistory();
}

function quickSelect(platform) {
    const input = document.getElementById('claimInput');
    input.value = `Please fact-check this claim from ${platform}: `;
    input.focus();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function handleImageUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    if (file.size > 4 * 1024 * 1024) {
        alert("Image is too large. Please upload an image smaller than 4MB.");
        return;
    }

    const reader = new FileReader();
    reader.onload = function(e) {
        currentBase64Image = e.target.result;
        document.getElementById('imagePreview').src = currentBase64Image;
        document.getElementById('imagePreviewContainer').style.display = 'block';
        document.getElementById('claimInput').value = ''; 
    };
    reader.readAsDataURL(file);
}

function removeImage() {
    currentBase64Image = null;
    document.getElementById('imageInput').value = '';
    document.getElementById('imagePreviewContainer').style.display = 'none';
}

async function verifyClaim() {
    const claimInput = document.getElementById('claimInput');
    const claim = claimInput.value.trim();
    
    if (!claim && !currentBase64Image) {
        alert('Please enter a claim, paste a link, or upload a screenshot.');
        return;
    }

    showScreen('loading');

    try {
        const response = await fetch('api/verify.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                claim: claim,
                image: currentBase64Image 
            })
        });
        
        const data = await response.json();
        
        if (data.error) {
            alert('Error: \n' + data.error);
            showScreen('home');
            return;
        }

        // 1. Update Verdict Banner
        const banner = document.getElementById('verdictBanner');
        banner.className = `verdict-banner ${data.verdict}`;
        document.getElementById('verdictText').innerText = data.verdict;
        
        const verdictDesc = document.getElementById('verdictDesc');
        if (data.verdict === 'TRUE') verdictDesc.innerText = 'This claim appears to be accurate.';
        else if (data.verdict === 'FALSE') verdictDesc.innerText = 'This claim contains false information.';
        else if (data.verdict === 'MISLEADING') verdictDesc.innerText = 'This claim contains partly false or missing context.';
        else verdictDesc.innerText = 'We could not definitively verify this claim.';

        // 2. Update Score & Details
        document.getElementById('scoreText').innerText = `${data.score}%`;
        document.getElementById('detailsText').innerText = data.details;

        // 3. Update Ring
        const ring = document.getElementById('scoreRing');
        const circumference = 283;
        const offset = circumference - (data.score / 100) * circumference;
        ring.style.strokeDashoffset = offset;

        // 4. Update Confidence Label
        const label = document.getElementById('scoreLabel');
        if (data.score >= 80) {
            ring.style.stroke = '#22C55E';
            label.innerText = 'High Confidence';
            label.style.color = '#22C55E';
        } else if (data.score >= 50) {
            ring.style.stroke = '#FACC15';
            label.innerText = 'Low Confidence';
            label.style.color = '#FACC15';
        } else {
            ring.style.stroke = '#EF4444';
            label.innerText = 'Unverified';
            label.style.color = '#EF4444';
        }

        // 5. SAVE TO LOCAL STORAGE
        saveToHistory(claim || "[Screenshot Uploaded]", data.verdict, data.score, data.details);

        showScreen('result');
        
        // Reset Inputs
        claimInput.value = '';
        removeImage();

    } catch (error) {
        console.error('Error verifying claim:', error);
        alert('A network error occurred. Please try again.');
        showScreen('home');
    }
}

// ==========================================
// LOCAL STORAGE HISTORY FUNCTIONS
// ==========================================

function saveToHistory(claim, verdict, score, details) {
    // Get existing history or empty array
    let history = JSON.parse(localStorage.getItem('trustTechHistory')) || [];
    
    // Create new item
    const newItem = {
        claim: claim,
        verdict: verdict,
        score: score,
        details: details,
        created_at: new Date().toISOString()
    };

    // Add to top of array
    history.unshift(newItem);

    // Keep only the latest 20 items to save space
    if (history.length > 20) history = history.slice(0, 20);

    // Save back to browser
    localStorage.setItem('trustTechHistory', JSON.stringify(history));
}

function loadHistory() {
    const list = document.getElementById('historyList');
    let history = JSON.parse(localStorage.getItem('trustTechHistory')) || [];
    
    if (history.length === 0) {
        list.innerHTML = `
            <div style="text-align:center; margin-top:50px; color:#94a3b8;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="width:50px; height:50px; margin-bottom:10px;"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                <p>No history yet.</p>
                <p style="font-size:12px;">Your verified claims will appear here.</p>
            </div>
        `;
        return;
    }

    list.innerHTML = history.map(item => {
        const shortClaim = item.claim.length > 60 ? item.claim.substring(0, 60) + '...' : item.claim;
        const date = new Date(item.created_at);
        const formattedDate = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' ' + date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

        return `
            <div class="history-item" onclick="viewHistoryItem('${item.claim.replace(/'/g, "\\'")}', '${item.verdict}', ${item.score}, '${item.details.replace(/'/g, "\\'")}')">
                <h4>"${shortClaim}"</h4>
                <div class="history-meta">
                    <span class="badge ${item.verdict}">${item.verdict}</span>
                    <span class="history-date">${formattedDate}</span>
                </div>
            </div>
        `;
    }).join('');
}

function viewHistoryItem(claim, verdict, score, details) {
    const banner = document.getElementById('verdictBanner');
    banner.className = `verdict-banner ${verdict}`;
    document.getElementById('verdictText').innerText = verdict;
    
    const verdictDesc = document.getElementById('verdictDesc');
    if (verdict === 'TRUE') verdictDesc.innerText = 'This claim appears to be accurate.';
    else if (verdict === 'FALSE') verdictDesc.innerText = 'This claim contains false information.';
    else if (verdict === 'MISLEADING') verdictDesc.innerText = 'This claim contains partly false or missing context.';
    else verdictDesc.innerText = 'We could not definitively verify this claim.';

    document.getElementById('scoreText').innerText = `${score}%`;
    document.getElementById('detailsText').innerText = details;

    const ring = document.getElementById('scoreRing');
    const circumference = 283;
    const offset = circumference - (score / 100) * circumference;
    ring.style.strokeDashoffset = offset;

    const label = document.getElementById('scoreLabel');
    if (score >= 80) {
        ring.style.stroke = '#22C55E';
        label.innerText = 'High Confidence';
        label.style.color = '#22C55E';
    } else if (score >= 50) {
        ring.style.stroke = '#FACC15';
        label.innerText = 'Low Confidence';
        label.style.color = '#FACC15';
    } else {
        ring.style.stroke = '#EF4444';
        label.innerText = 'Unverified';
        label.style.color = '#EF4444';
    }

    showScreen('result');
}

function shareResult() {
    const verdict = document.getElementById('verdictText').innerText;
    const score = document.getElementById('scoreText').innerText;
    const details = document.getElementById('detailsText').innerText;

    const shareText = `TrustTech Verification Result:\n\nVerdict: ${verdict}\nCredibility Score: ${score}\n\nDetails: ${details}\n\nVerify your own claims at TrustTech!`;

    if (navigator.share) {
        navigator.share({
            title: 'TrustTech Verification',
            text: shareText,
            url: window.location.href
        }).catch((error) => console.log('Error sharing', error));
    } else {
        navigator.clipboard.writeText(shareText).then(() => {
            alert('Result copied to clipboard! You can now paste it to share.');
        }).catch(() => {
            alert('Could not copy result. Please take a screenshot instead.');
        });
    }
}

function clearHistory() {
    if (confirm('Are you sure you want to clear your history?')) {
        localStorage.removeItem('trustTechHistory');
        loadHistory(); // Reload to show empty state
    }
}
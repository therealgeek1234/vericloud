<?php

$host = 'sql103.infinityfree.com';
$dbname = 'if0_43339313_trusttech';
$username = 'if0_43339313';
$password = 'caCACoc3RLR';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
<?php
// Get your free API key at: https://aistudio.google.com/
define('GROQ_API_KEY', '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');
?>
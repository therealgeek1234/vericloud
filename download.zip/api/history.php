<?php
header('Content-Type: application/json');
require_once 'config/database.php';

$stmt = $pdo->query("SELECT * FROM verification_history ORDER BY created_at DESC LIMIT 20");
$history = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($history);
?>
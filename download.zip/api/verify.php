<?php
// 1. Force JSON output and catch ALL errors
header('Content-Type: application/json');
ini_set('display_errors', 0); // Don't output HTML errors directly
error_reporting(E_ALL);

// Custom error handler to catch fatal errors and return JSON
function jsonErrorHandler($errno, $errstr, $errfile, $errline) {
    echo json_encode([
        'error' => "PHP Error: $errstr in $errfile on line $errline"
    ]);
    exit;
}
set_error_handler("jsonErrorHandler");

// Catch fatal errors (like calling a function that doesn't exist)
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error !== NULL && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        echo json_encode([
            'error' => "PHP Fatal Error: " . $error['message'] . " in " . $error['file'] . " on line " . $error['line']
        ]);
    }
});

require_once '../config/config.php';
require_once '../config/database.php';

$data = json_decode(file_get_contents('php://input'), true);
$claim = $data['claim'] ?? '';
$imageBase64 = $data['image'] ?? null;

if (empty($claim) && empty($imageBase64)) {
    echo json_encode(['error' => 'No claim or image provided']);
    exit;
}

$prompt = "You are a professional fact-checker. Analyze this claim or the text in this image. 
Return ONLY a valid JSON object with exactly these keys:
- 'verdict': string (must be exactly one of: 'TRUE', 'FALSE', 'MISLEADING', 'UNVERIFIED')
- 'score': integer (0 to 100, where 100 is highly credible)
- 'details': string (A short 2-3 sentence explanation of why).";

$model = "openai/gpt-oss-120b"; // Default text model
$messageContent = $prompt . "\n\nClaim to verify: " . $claim;

// IF IMAGE EXISTS, SWITCH TO VISION MODEL
if ($imageBase64) {
    $model = "qwen/qwen3.8-27b"; 
    
    $messageContent = [
        ["type" => "text", "text" => $prompt . ($claim ? "\n\nContext provided: " . $claim : "")],
        ["type" => "image_url", "image_url" => ["url" => $imageBase64]]
    ];
}

$url = "https://api.groq.com/openai/v1/chat/completions";

$payload = [
    "model" => $model,
    "messages" => [
        ["role" => "user", "content" => $messageContent]
    ],
    "response_format" => ["type" => "json_object"]
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . GROQ_API_KEY
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_error = curl_error($ch);
curl_close($ch);

if ($curl_error) {
    echo json_encode(['error' => 'Network Error: ' . $curl_error]);
    exit;
}

$result = json_decode($response, true);

if ($http_code !== 200) {
    $apiError = $result['error']['message'] ?? 'Unknown Groq API Error';
    echo json_encode(['error' => 'Groq API Error: ' . $apiError]);
    exit;
}

$aiText = $result['choices'][0]['message']['content'] ?? '{}';
$aiData = json_decode($aiText, true);

if (!$aiData || !isset($aiData['verdict'])) {
    echo json_encode(['error' => 'AI failed to return valid JSON.', 'raw_ai_text' => $aiText]);
    exit;
}

$verdict = $aiData['verdict'];
$score = $aiData['score'];
$details = $aiData['details'];

$displayClaim = $claim ?: "[Screenshot Uploaded]";

try {
    $stmt = $pdo->prepare("INSERT INTO verification_history (claim, verdict, score, details) VALUES (?, ?, ?, ?)");
    $stmt->execute([$displayClaim, $verdict, $score, $details]);
} catch (Exception $e) {
    // Ignore DB error
}

echo json_encode([
    'verdict' => $verdict,
    'score' => $score,
    'details' => $details
]);
?>